var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/weather.ts
var weather_exports = {};
__export(weather_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(weather_exports);
var SF_LATITUDE = 37.7749;
var SF_LONGITUDE = -122.4194;
var WEATHER_KV_KEY = "weather/san-francisco";
var FORECAST_URL = "https://api.open-meteo.com/v1/forecast?latitude=37.7749&longitude=-122.4194&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=America/Los_Angeles";
function weatherDescription(code) {
  if (code == null)
    return "Unknown conditions";
  if (code === 0)
    return "Clear sky";
  if (code === 1)
    return "Mainly clear";
  if (code === 2)
    return "Partly cloudy";
  if (code === 3)
    return "Overcast";
  if (code === 45 || code === 48)
    return "Fog";
  if (code >= 51 && code <= 57)
    return "Drizzle";
  if (code >= 61 && code <= 67)
    return "Rain";
  if (code >= 71 && code <= 77)
    return "Snow";
  if (code >= 80 && code <= 82)
    return "Rain showers";
  if (code >= 85 && code <= 86)
    return "Snow showers";
  if (code >= 95)
    return "Thunderstorm";
  return `Weather code ${code}`;
}
async function resolveTrigger(request) {
  try {
    const text = await request.text();
    if (!text)
      return "manual";
    const body = JSON.parse(text);
    if (typeof body.scheduleId === "string" || body.trigger === "scheduled") {
      return "scheduled";
    }
  } catch {
  }
  return "manual";
}
function asNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
async function onRequest(request, context) {
  const trigger = await resolveTrigger(request);
  console.log("[weather] running", { trigger, at: (/* @__PURE__ */ new Date()).toISOString() });
  const forecastRes = await fetch(FORECAST_URL);
  if (!forecastRes.ok) {
    const detail = await forecastRes.text();
    console.log("[weather] Open-Meteo request failed", { status: forecastRes.status, detail });
    return new Response(JSON.stringify({ error: "Failed to fetch weather", detail }), {
      status: 502,
      headers: { "content-type": "application/json" }
    });
  }
  const forecast = await forecastRes.json();
  const current = forecast.current ?? {};
  const weatherCode = asNumber(current.weather_code);
  const snapshot = {
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    trigger,
    location: "San Francisco",
    latitude: SF_LATITUDE,
    longitude: SF_LONGITUDE,
    temperatureC: asNumber(current.temperature_2m),
    humidityPercent: asNumber(current.relative_humidity_2m),
    windSpeedKmh: asNumber(current.wind_speed_10m),
    weatherCode,
    description: weatherDescription(weatherCode)
  };
  const kvRes = await fetch(`/api/v1/a/${context.appId}/kvstore/${WEATHER_KV_KEY}`, {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(snapshot)
  });
  if (!kvRes.ok) {
    console.log("[weather] failed to cache snapshot", { status: kvRes.status });
  }
  return new Response(JSON.stringify(snapshot), {
    status: 200,
    headers: { "content-type": "application/json" }
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=weather.js.map
