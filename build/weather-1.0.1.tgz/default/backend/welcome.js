var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/welcome.ts
var welcome_exports = {};
__export(welcome_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(welcome_exports);
async function onRequest(_request, _context) {
  const message = "Welcome to cribl Apps";
  console.log("[welcome] running", { message, at: (/* @__PURE__ */ new Date()).toISOString() });
  return new Response(JSON.stringify({ message }), {
    status: 200,
    headers: { "content-type": "application/json" }
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=welcome.js.map
